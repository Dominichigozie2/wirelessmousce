這是一款支持泰文和歐美地區主要拉丁文的字體。採用高挑的骨架和極細單線塑造精緻、優雅和時尚的形象。本款字體供個人及商業免費使用。這是我作為泰文初學者的一次實驗性設計作品。在保留泰文識別度的基礎上，讓其視覺更趨向於幾何型態。根據泰文的基調風格延展出可配合使用的拉丁文字及符號，最終字體字符達466個，可支持至少77種語言使用。

-

ฟอนต์นี้รองรับภาษาไทยและภาษาหลักที่ใช้ภาษาลาตินในยุโรปและอเมริกา สัดส่วนของตัวอักษรค่อนข้างแคบและบางมาก เป็นฟอนต์ที่มีรูปแบบเรียบหรู ทันสมัย ฟอนต์นี้มีวัตถุประสงค์ให้ใช้ฟรี ไม่มีค่าใช้จ่ายใดๆ อีกทั้งอนุญาตให้ใช้ในเชิงพาณิชย์

ฟอนต์นี้เป็นงานออกแบบเชิงทดลองสำหรับชาวต่างชาติที่เพิ่งเรียนภาษาไทย ยังคงรักษาเอกลักษณ์พื้นฐานของตัวอักษรไทยไว้

-

Pure Pin is a thin and experimental typeface with narrow proportions and light weight. It supports Thai and main latin-base languages from European and American regions. It’s a trendy, elegant and modern style font. This font is free for personal and commercial use. 

Enjoy it :)

-

DESIGNED BY FEARLESS LEI

https://www.behance.net/0411fearless

Pay what you like:

https://replayfonts.gumroad.com/l/purepin